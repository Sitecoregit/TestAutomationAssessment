# Pre-requisites

1. Update the 'systempath' variable in the pom.xml depending upon the jdk version
<systemPath>C:/Program Files/Java/jdk1.8.0_141/lib/tools.jar</systemPath>

2. Maven should be installed in the system to run in command prompt
also the value of MAVEN_HOME should be set in environmental variables

# Setting up the Browser

- Go to 'com.AppProperties.java'
- Update the browser in which we want the test to be executed
- Update the URLs and the search terms (optional)

# Setting up the drivers

- Make sure the below required drivers are available in the 'lib' folder of the project location
- Chromedriver --> lib/chromedrivers/chromedriver.exe
- Geckodriver --> lib/geckodriver/geckodriver.exe
- IEDriver --> lib/iedriver/IEDriverServer.exe

# Feature files are available in the below location

- features

# Execution via JUnit
- Open --> com.runner.testRunner.java file
- Right click on 'TestRunner.java' file 
- Run As 'JUnit Test'

# Execution via TestNG
- Open --> com.runner.TestNG_Config.xml file
- Right click on 'TestNG_Config.xml' file 
- Run As 'TestNG Suite'

# Parallel Execution using TestNG
- open 'com.runner.TestNG_Config.xml' file
- Update the thread count as 2
- Also Executing in different browsers are possible by updting the below parameter inside each 'test' section

Eg:
For Chrome--> parameter name="browserName" value="Chrome"
For Firefox--> parameter name="browserName" value="Firefox"

# Viewing Reports
- Refer the JUnit console, if ran using JUnit
- Refer 'test-output'/'emailable-report.html', if ran using TestNG.
- Screenshots can be found on 'screenshots' folder










