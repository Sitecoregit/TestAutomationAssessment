package com;

public class AppProperties {

	// Possible Values- Chrome, Firefox, InternetExplorer
	public static String browserName = "Chrome";

	public static String expedia_url = "https://expedia.com";
	public static String google_url = "https://google.com";
	public static String firstSearchTerm = "Bahamas";
	public static String secondSearchTerm = "Amsterdam";

	public static int expectedAdultsCount = 1;
	public static int expectedChildsCount = 1;
	public static int childsAge = 3;
	
	public static String getExpediaWebsitUrl() {
		return expedia_url;
	}

	public static void setBrowserName(String browser) {
		browserName = browser;
	}

	public static String getBrowserName() {
		return browserName;
	}

	public static String getGoogleUrl() {
		return google_url;
	}

	public static String get1stSearchTerm() {
		return firstSearchTerm;
	}

	public static String get2ndSearchTerm() {
		return secondSearchTerm;
	}
	
	public static int getExpectedAdultsCount() {
		return expectedAdultsCount;
	}
	
	public static int getExpectedChildsCount() {
		return expectedChildsCount;
	}
	
	public static int getChildsAge() {
		return childsAge;
	}
}
