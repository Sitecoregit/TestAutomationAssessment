package com.stepDefinition;

import org.openqa.selenium.WebDriver;

public class BaseUtils {

	public static WebDriver driver;

	public static String reportLocation = System.getProperty("user.dir") + "//Reports";
}
