package com.stepDefinition.pages;

import org.openqa.selenium.By;

public class ExpedianHomePage {

	// Package fields
	public static final By lblPackages = By.xpath("//span[.='Packages']");

	public static final By btnAddAStay = By.xpath("//label[@for='package-pills-hotels']/span");

	public static final By btnAddAFlight = By.xpath("//label[@for='package-pills-flights']/span");

	public static final By txtLeavingfrom = By
			.xpath("//input[@id='location-field-origin-input']/following-sibling::button[1]");

	public static final By lblLeavingfrom1stResult = By
			.xpath("(//li[@data-stid='location-field-origin-result-item'])[1]");

	public static final By txtGoingto = By
			.xpath("//input[@id='location-field-destination-input']/following-sibling::button[1]");

	public static final By lblGoingto1stResult = By
			.xpath("(//button[@data-stid='location-field-destination-result-item-button'])[1]");

	// Travelers field

	public static final By btnTravelersField = By.xpath("//a[@data-testid='travelers-field']");

	public static final By lblAdultCount = By.xpath("//input[@id='adult-input-0']");

	public static final By btnAdultCountIncrease = By
			.xpath("//input[@id='adult-input-0']/following-sibling::button[1]");

	public static final By btnAdultCountDecrease = By
			.xpath("//input[@id='adult-input-0']/preceding-sibling::button[1]");

	public static final By lblChildCount = By.xpath("//input[@id='child-input-0']");

	public static final By btnChildCountIncrease = By
			.xpath("//input[@id='child-input-0']/following-sibling::button[1]");

	public static final By btnChildCountDecrease = By
			.xpath("//input[@id='child-input-0']/preceding-sibling::button[1]");

	public static final By txtChildsAge = By.xpath("//select[@id='child-age-input-0-0']");

	public static final By listChildsAgeDropdown = By
			.xpath("//select[@id='child-age-input-0-0']/option[@value='REPLACE']");

	public static final By btnTravelersDone = By.xpath("//button[@data-testid='guests-done-button']");

	// Calendar Field

	public static final By btnOpenDatePicker = By.xpath("(//button[@data-stid='open-date-picker'])[1]");

	public static final By lblCalendarDateAfter20days = By.xpath("(//button[@class='uitk-new-date-picker-day'])[20]");

	public static final By lblCalendarDateAfter21days = By.xpath("(//button[@class='uitk-new-date-picker-day'])[22]");

	public static final By btnCalendarDone = By.xpath("//button[@data-stid='apply-date-picker']/span[1]");

	// Other fields

	public static final By chkPartialStay = By.xpath("//input[@id='package-partial-stay']");

	public static final By btnPackageSearch = By.xpath("//button[@data-testid='submit-button']");

	public static final By listPropertySearchResults = By.xpath("//li[@data-stid='property-listing']");

	/**
	 * 
	 * Getter Methods
	 */
	public static By getLblPackages() {
		return lblPackages;
	}

	public static By getBtnAddAStay() {
		return btnAddAStay;
	}

	public static By getBtnAddAFlight() {
		return btnAddAFlight;
	}

	public static By getTxtLeavingfrom() {
		return txtLeavingfrom;
	}

	public static By getLblLeavingfrom1stResult() {
		return lblLeavingfrom1stResult;
	}

	public static By getTxtGoingto() {
		return txtGoingto;
	}

	public static By getLblGoingto1stResult() {
		return lblGoingto1stResult;
	}

	public static By getBtnTravelersField() {
		return btnTravelersField;
	}

	public static By getLblAdultCount() {
		return lblAdultCount;
	}

	public static By getBtnAdultCountIncrease() {
		return btnAdultCountIncrease;
	}

	public static By getBtnAdultCountDecrease() {
		return btnAdultCountDecrease;
	}

	public static By getLblChildCount() {
		return lblChildCount;
	}

	public static By getBtnChildCountIncrease() {
		return btnChildCountIncrease;
	}

	public static By getBtnChildCountDecrease() {
		return btnChildCountDecrease;
	}

	public static By getListChildsAgeDropdown() {
		return listChildsAgeDropdown;
	}

	public static By gettxtChildsAge() {
		return txtChildsAge;
	}

	public static By getBtnTravelersDone() {
		return btnTravelersDone;
	}

	public static By getBtnOpenDatePicker() {
		return btnOpenDatePicker;
	}

	public static By getLblCalendarDateAfter20days() {
		return lblCalendarDateAfter20days;
	}

	public static By getLblCalendarDateAfter21days() {
		return lblCalendarDateAfter21days;
	}

	public static By getBtnCalendarDone() {
		return btnCalendarDone;
	}

	public static By getChkPartialStay() {
		return chkPartialStay;
	}

	public static By getBtnPackageSearch() {
		return btnPackageSearch;
	}

	public static By getListPropertySearchResults() {
		return listPropertySearchResults;
	}
}
