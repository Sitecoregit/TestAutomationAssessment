package com.stepDefinition.pages;

import org.openqa.selenium.By;

public class GoogleSearchresultsPage {

	public static final By txtSearchbox = By.xpath("//input[@title='Search']");

	public static final By imgGoogle = By.xpath("//img[@alt=\"Google\"]");

	public static final By lblSearchResults = By.xpath("//div[@id='result-stats']");

	/**
	 * 
	 * Getter Methods
	 */
	public static By getTxtSearchbox() {
		return txtSearchbox;
	}

	public static By getImgGoogle() {
		return imgGoogle;
	}

	public static By getLblSearchResults() {
		return lblSearchResults;
	}

}