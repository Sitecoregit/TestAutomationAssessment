package com.stepDefinition.pages;

import org.openqa.selenium.By;

public class GoogleHomeTestPage {

	public static final By txtSearchbox = By.xpath("//input[@title='Search']");

	public static final By btnSearch = By.xpath("(//input[@value='Google Search'])[2]");

	public static final By btnIntroAgree = By.xpath("(//span[.='I agree'])[2]");

	/**
	 * 
	 * Getter Methods
	 */
	public static By getTxtSearchbox() {
		return txtSearchbox;
	}

	public static By getBtnsearch() {
		return btnSearch;
	}

	public static By getBtnIntroAgree() {
		return btnIntroAgree;
	}

}
