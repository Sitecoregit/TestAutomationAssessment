package com.stepDefinition;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

public class CommonUtils {

	/**
	 * To hover the mouse pointer over an element in a webpage
	 * 
	 * @param driver
	 * @param moveElement
	 */
	public static void mousehover(WebDriver driver, WebElement moveElement) {
		// Java Script
		String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover', true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement element = (WebElement) moveElement;
		js.executeScript(mouseOverScript, element);
	}

	/**
	 * To scroll to an element in the webpage
	 * 
	 * @param driver
	 * @param element
	 */
	public static void scrolltoelement(WebDriver driver, WebElement element) {

		try {
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		} catch (Exception e) {
			Reporter.log("Error occured while scrolling to the elemenet.");
		}
	}

}
