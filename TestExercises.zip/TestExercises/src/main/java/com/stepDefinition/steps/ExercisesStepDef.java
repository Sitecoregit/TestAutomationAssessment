package com.stepDefinition.steps;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.AppProperties;
import com.stepDefinition.BaseUtils;
import com.stepDefinition.pages.ExpedianHomePage;
import com.stepDefinition.pages.GoogleHomeTestPage;
import com.stepDefinition.pages.GoogleSearchresultsPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ExercisesStepDef extends BaseUtils {

	@Given("^User launch \"(.*?)\"$")
	public void user_launch(String url) {
		String browserName = AppProperties.getBrowserName();
		setBrowser(browserName, url);

		boolean isIntroPopupPresent = false;

		/**
		 * Handling the Intro/consent Popup and clicking on I agree button
		 * 
		 */
		if (url.contains("google")) {
			try {

				int i = 0;
				while (i < 5) {
					driver.switchTo().frame(0);
					WebElement elementBtnIntroAgree = driver.findElement(GoogleHomeTestPage.getBtnIntroAgree());

					if (elementBtnIntroAgree.isDisplayed()) {
						elementBtnIntroAgree.click();
						Reporter.log("Clicked on I agree button from the Intro screen..");
						isIntroPopupPresent = true;
					}

					i++;
				}
			} catch (Exception e) {

				if (isIntroPopupPresent) {
					System.out.println("Intro popup handled..");
				} else {
					System.out.println("No Intro popup found..");
				}

			}
		}
	}

	@Test
	@Parameters("browserName")
	public void Exercise1_GoogleSearch(String browserName) throws Throwable {
		AppProperties.setBrowserName(browserName);
		user_launch(AppProperties.getGoogleUrl());
		user_search_for_the_keyword(AppProperties.get1stSearchTerm());
		user_should_see_the_results_page(AppProperties.get1stSearchTerm());
		user_search_for_the_keyword(AppProperties.get2ndSearchTerm());
		user_should_see_the_results_page(AppProperties.get2ndSearchTerm());
		clopseapp();
	}

	@Given("^User search for the keyword \"(.*?)\"$")
	public void user_search_for_the_keyword(String searchTerm) {
		WebElement elementSearchbox = driver.findElement(GoogleHomeTestPage.getTxtSearchbox());
		elementSearchbox.clear();
		elementSearchbox.sendKeys(searchTerm);
		Reporter.log("Searchterm '" + searchTerm + "' entered.");
		// driver.findElement(GoogleHomeTestPage.btnSearch).click();
		driver.findElement(GoogleHomeTestPage.getTxtSearchbox()).sendKeys(Keys.ENTER);
		Reporter.log("Clicked search button..");
	}

	@Then("^User should see the \"(.*?)\" results page$")
	public void user_should_see_the_results_page(String searchedTerm) throws Throwable {
		takescreenshot();

		if (driver.findElement(GoogleSearchresultsPage.getLblSearchResults()).isDisplayed()) {
			Reporter.log("Navigated to Search results page.");

			String searchResults = driver.findElement(GoogleSearchresultsPage.getLblSearchResults()).getText();
			Reporter.log(searchResults + " found.");

		} else {
			throw new Exception("Not navigated to Search results page");
		}

	}

	@Given("^I navigate to the Expedia website$")
	public void i_navigate_to_the_Expedia_website() {
		String browserName = AppProperties.getBrowserName();
		setBrowser(browserName, AppProperties.getExpediaWebsitUrl());
	}

	@When("^I look for a flight and accomodation from Brussels to New York$")
	public void i_look_for_a_flight_accomodation_from_Brussels_to_New_York() throws Throwable {

		driver.findElement(ExpedianHomePage.getLblPackages()).click();
		Reporter.log("Clciked on Packages..");

		verifyIfStayAdded();
		verifyIfFlightAdded();

		// Enter from and To places
		enterFromAndToPlaces("Brussels", "New York");

		// format: ('expectedAdultsCount', 'expectedChildsCount','ChildsAge')
		selectTravelerDetails(AppProperties.getExpectedAdultsCount(), AppProperties.getExpectedChildsCount(),
				AppProperties.getChildsAge());

		// Select date fields
		selectDateFields();

		// Click on Search button
		driver.findElement(ExpedianHomePage.getChkPartialStay()).click();
		driver.findElement(ExpedianHomePage.getBtnPackageSearch()).click();
		Reporter.log("Clicked on Search button..");
		takescreenshot();
	}

	@Test
	@Parameters("browserName")
	public void Exercise2_ExpediaFlightBookings(String browserName) throws Throwable {
		AppProperties.setBrowserName(browserName);
		i_navigate_to_the_Expedia_website();
		i_look_for_a_flight_accomodation_from_Brussels_to_New_York();
		the_result_page_contains_travel_option_for_the_chosen_destination();
		clopseapp();
	}

	/**
	 * Verifies if stay has been added. else, clicks on the 'Add a stay' button
	 * 
	 */
	public void verifyIfStayAdded() {

		String stayText = driver.findElement(ExpedianHomePage.getBtnAddAStay()).getText();

		if (!stayText.equalsIgnoreCase("Stay added")) {
			driver.findElement(ExpedianHomePage.getBtnAddAStay()).click();
		}

	}

	/**
	 * Verifies if flight has been added. else, clicks on the 'Add a flight' button
	 * 
	 */
	public void verifyIfFlightAdded() {

		String stayText = driver.findElement(ExpedianHomePage.getBtnAddAFlight()).getText();

		if (!stayText.equalsIgnoreCase("Flight added")) {
			driver.findElement(ExpedianHomePage.getBtnAddAFlight()).click();
		}
	}

	/**
	 * Enters 'From' and 'To' places From --> Brussels To --> New York
	 * 
	 * @param fromPlace
	 * @param toPlace
	 * @throws InterruptedException
	 */
	public void enterFromAndToPlaces(String fromPlace, String toPlace) throws InterruptedException {

		driver.findElement(ExpedianHomePage.getTxtLeavingfrom()).sendKeys(fromPlace);

		Thread.sleep(1000);
		driver.findElement(ExpedianHomePage.getLblLeavingfrom1stResult()).isDisplayed();
		driver.findElement(ExpedianHomePage.getLblLeavingfrom1stResult()).click();

		Reporter.log("Selected 'Leaving from' as: " + fromPlace);

		driver.findElement(ExpedianHomePage.getTxtGoingto()).sendKeys(toPlace);

		Thread.sleep(1000);
		driver.findElement(ExpedianHomePage.getLblGoingto1stResult()).isDisplayed();
		driver.findElement(ExpedianHomePage.getLblGoingto1stResult()).click();

		Reporter.log("Selected 'Going to' as: " + toPlace);
	}

	/**
	 * 
	 * Selects 'Traveller details' and cliks on 'Done' button Adults count --> as
	 * per the passed argument. i.e, expectedAdultsCount Childs count --> as per the
	 * passed argument. i.e, expectedChildsCount Childs age --> as per the passed
	 * argument. i.e, childsAge
	 * 
	 * @param expectedAdultsCount
	 * @param expectedChildsCount
	 * @param childsAge
	 * @throws InterruptedException
	 */
	public void selectTravelerDetails(int expectedAdultsCount, int expectedChildsCount, int childsAge)
			throws InterruptedException {

		driver.findElement(ExpedianHomePage.getBtnTravelersField()).click();

		// Set Adults and Childs count
		setAdultsCount(expectedAdultsCount);
		setChildsCount(expectedChildsCount);

		// Select Childs age

		Select childsAgeDropdown = new Select(driver.findElement(ExpedianHomePage.gettxtChildsAge()));
		childsAgeDropdown.selectByValue(Integer.toString(childsAge));
		Reporter.log("Childs age has been set to " + childsAge);

		// Click on Done button from the traveler details field
		driver.findElement(ExpedianHomePage.getBtnTravelersDone()).click();
		Reporter.log("Traveler details selected..");

	}

	/**
	 * Sets the Adults count as per the value in the passed argument-
	 * expectedAdultsCount
	 * 
	 * @param expectedAdultsCount
	 */
	public void setAdultsCount(int expectedAdultsCount) {

		int numberOfAdults = Integer
				.parseInt(driver.findElement(ExpedianHomePage.getLblAdultCount()).getAttribute("value"));

		if (numberOfAdults == expectedAdultsCount) {

		} else if (numberOfAdults > expectedAdultsCount) {

			int i = 0;
			while ((numberOfAdults > expectedAdultsCount) && (i < 5)) {
				driver.findElement(ExpedianHomePage.getBtnAdultCountDecrease()).click();
				numberOfAdults = Integer
						.parseInt(driver.findElement(ExpedianHomePage.getLblAdultCount()).getAttribute("value"));
				i++;
			}

		} else {
			int i = 0;
			while ((numberOfAdults < expectedAdultsCount) && (i < 5)) {
				driver.findElement(ExpedianHomePage.getBtnAdultCountIncrease()).click();
				numberOfAdults = Integer
						.parseInt(driver.findElement(ExpedianHomePage.getLblAdultCount()).getAttribute("value"));
				i++;
			}
		}
		Reporter.log("Adult count has been set to " + expectedAdultsCount);
	}

	/**
	 * Sets the Childs count as per the value in the passed argument-
	 * expectedChildsCount
	 * 
	 * @param expectedChildsCount
	 */
	public void setChildsCount(int expectedChildsCount) {

		int numberOfChilds = Integer
				.parseInt(driver.findElement(ExpedianHomePage.getLblChildCount()).getAttribute("value"));

		if (numberOfChilds == expectedChildsCount) {

		} else if (numberOfChilds > expectedChildsCount) {

			int i = 0;
			while ((numberOfChilds > expectedChildsCount) && (i < 5)) {
				driver.findElement(ExpedianHomePage.getBtnChildCountDecrease()).click();
				numberOfChilds = Integer
						.parseInt(driver.findElement(ExpedianHomePage.getLblChildCount()).getAttribute("value"));
				i++;
			}

		} else {
			int i = 0;
			while ((numberOfChilds < expectedChildsCount) && (i < 5)) {
				driver.findElement(ExpedianHomePage.getBtnChildCountIncrease()).click();
				numberOfChilds = Integer
						.parseInt(driver.findElement(ExpedianHomePage.getLblChildCount()).getAttribute("value"));
				i++;
			}
		}
		Reporter.log("Child count has been set to " + expectedChildsCount);
	}

	/**
	 * To Select, From & To date, as 20 days from the present date respectively
	 * 
	 * @throws InterruptedException
	 */
	public void selectDateFields() throws InterruptedException {
		driver.findElement(ExpedianHomePage.getBtnOpenDatePicker()).click();

		Thread.sleep(2000);
		driver.findElement(ExpedianHomePage.getLblCalendarDateAfter20days()).isDisplayed();
		driver.findElement(ExpedianHomePage.getLblCalendarDateAfter20days()).click();

		driver.findElement(ExpedianHomePage.getBtnCalendarDone()).isDisplayed();
		driver.findElement(ExpedianHomePage.getBtnCalendarDone()).click();

		Reporter.log("Selected date from the date picker..");

	}

	@Then("^the result page contains travel option for the chosen destination$")
	public void the_result_page_contains_travel_option_for_the_chosen_destination() throws Throwable {
		boolean isSearchResultsDisplayed = driver.findElement(ExpedianHomePage.getListPropertySearchResults())
				.isDisplayed();

		int i = 0;
		while ((i < 7) & !isSearchResultsDisplayed) {

			Thread.sleep(2000);
			isSearchResultsDisplayed = driver.findElement(ExpedianHomePage.getListPropertySearchResults())
					.isDisplayed();
			i++;
		}

		takescreenshot();
		if (!isSearchResultsDisplayed) {
			throw new Exception("Search results not displayed..");
		} else {
			Reporter.log("Search results have been validated..");
		}
	}

	@Then("User closes the app")
	public void User_closes_the_app() {
		clopseapp();
	}

	/**
	 * 
	 * Sets the browser in which the tests needs to be executed
	 * 
	 * @param browserType
	 * @param appURL
	 */
	public static void setBrowser(String browserType, String appURL) {

		if (browserType.equalsIgnoreCase("Chrome")) {
			driver = initChromeDriver(appURL);
		} else if (browserType.equalsIgnoreCase("Firefox")) {
			driver = initFirefoxDriver(appURL);
		} else if (browserType.equalsIgnoreCase("InternetExplorer")) {
			driver = initIEDriver(appURL);
		} else if (browserType.equalsIgnoreCase("Safari")) {
			driver = initSafariDriver(appURL);
		}
	}

	/**
	 * Initializes the chromedriver and launches the App URL.
	 * 
	 * @param appURL
	 * @return
	 */
	static WebDriver initChromeDriver(String appURL) {
		System.out.println("Launching Google Chrome..");
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "//lib//chromedriver//chromedriver");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to(appURL);
		return driver;
	}

	/**
	 * Initializes the IEDriver and launches the App URL.
	 * 
	 * @param appURL
	 * @return
	 */
	static WebDriver initIEDriver(String appURL) {
		System.out.println("Launching Internet Explorer..");
		System.setProperty("system.webdriver.ie.driver",
				System.getProperty("user.dir") + "\\lib\\iedriver\\IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		driver.manage().window().maximize();
		driver.navigate().to(appURL);
		return driver;
	}

	/**
	 * Initializes the SafariDriver and launches the App URL.
	 * 
	 * @param appURL
	 * @return
	 */
	static WebDriver initSafariDriver(String appURL) {
		System.out.println("Launching Safari..");
		System.setProperty("system.webdriver.ie.driver",
				System.getProperty("user.dir") + "\\lib\\Safaridriver\\IEDriverServer.exe");
		driver = new SafariDriver();
		driver.manage().window().maximize();
		driver.navigate().to(appURL);
		return driver;
	}

	/**
	 * Initializes the firefox and launches the App URL.
	 * 
	 * @param appURL
	 * @return
	 */
	static WebDriver initFirefoxDriver(String appURL) {
		System.out.println("Launching Firefox browser..");
		System.setProperty("webdriver.gecko.driver",
				System.getProperty("user.dir") + "\\lib\\gechodriver\\geckodriver.exe");

		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.navigate().to(appURL);
		return driver;
	}

	/**
	 * Takes screenshot and saves in the 'screenshots' folder in the project
	 * location
	 * 
	 * @throws Throwable
	 */
	public static void takescreenshot() throws Throwable {
		TakesScreenshot scrShot = ((TakesScreenshot) driver);
		File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);
		String filename = new SimpleDateFormat("yyyyMMddhhmmss'.jpeg'").format(new Date());
		File dest = new File(System.getProperty("user.dir") + "//screenshots//" + filename);
		FileUtils.copyFile(SrcFile, dest);
	}

	/**
	 * Closes the current driver session
	 */
	public static void clopseapp() {
		System.out.println("In close app..");
		driver.close();
	}

}
